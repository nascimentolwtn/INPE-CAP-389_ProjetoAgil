package test.exemplo;

public class DivisionCalc {

    public static float calc(int x, int y) {
        return (x / y);
    }

}
